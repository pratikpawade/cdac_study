using Tourism.Models;

//builder provides access to services, middleware, and configuration for the app.
var builder = WebApplication.CreateBuilder(args);

//Razor views are not required for client-side rendering
//This registers controller services with the dependency injection (DI) container.
//Controllers handle HTTP requests and responses, and this line makes sure that they are available when the app runs.
builder.Services.AddControllers(); 

//one service object per request
//Scoped lifetime means a new instance of SiteModel will be created once per HTTP request and shared throughout that request.
//This ensures consistency for operations related to the request and avoids unnecessary overhead.
builder.Services.AddScoped<SiteModel>();

//This builds the application after configuration is complete.
//The app object represents the fully configured web application.
var app = builder.Build();


app.UseDefaultFiles(); //make wwwroot/index.html default page
app.UseStaticFiles(); //Enables the serving of static files (like images, CSS, JavaScript) from the wwwroot directory.
app.UseRouting(); //Enables routing middleware, which maps incoming HTTP requests to the correct endpoints (like controllers).
app.MapControllers(); //enable attribute based route-mapping
app.Run();
