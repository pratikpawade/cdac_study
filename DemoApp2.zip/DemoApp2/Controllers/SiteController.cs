using Microsoft.AspNetCore.Mvc;
using Tourism.Data;
using Tourism.Models;

namespace DemoApp.Controllers;

[ApiController]
public class SiteController : ControllerBase
{
    [HttpGet("/api/site")] //This attribute defines an HTTP GET endpoint at /api/site
    //IActionResult: Represents the result of an action. It can return various HTTP responses, such as Ok() or NotFound().
    //SiteModel model: This is injected from dependency injection (DI). It provides access to methods that manage visitor data.
    public IActionResult ReadVisitors(SiteModel model)
    {
        var visitors = model.GetVisitors(); //Calls the GetVisitors method from SiteModel, retrieving a list of visitors.
        //If there are any visitors, it returns an HTTP 200 OK response with the list of visitors.
        //Ok(visitors) sends the visitor list in the response body.
        if(visitors.Any())
            return Ok(visitors);
        //If no visitors are found, it returns HTTP 404 Not Found to indicate that the resource is unavailable.
        return NotFound();
    }

    [HttpPost("/api/site")]
    //Traveler input: The request body is deserialized into a Traveler object, representing the visitor’s data.
    //SiteModel model: This is again injected from DI to manage visitor operations.
    public IActionResult WriteVisitor(Traveler input, SiteModel model)
    {
        //Calls the AcceptVisit method from SiteModel, passing the visitor’s ID and rating to register their visit.
        model.AcceptVisit(input.Id, input.Rating);
        return Ok();
    }
}

// Summary of Functionality:
// Controller Name: SiteController
// Endpoints:
// GET /api/site:
// Retrieves a list of visitors from SiteModel.
// If visitors are found, returns 200 OK with the data.
// If no visitors, returns 404 Not Found.
// POST /api/site:
// Accepts a new visitor’s data from the request body.
// Calls AcceptVisit to register the visit.
// Returns 200 OK if the operation succeeds.
//This controller follows REST principles, exposing the GET and POST methods for interacting with visitor data. Dependency Injection (DI) ensures the SiteModel is injected automatically, keeping the code modular and easy to maintain.