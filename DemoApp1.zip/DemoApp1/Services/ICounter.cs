namespace DemoApp.Services;

public interface ICounter
{
    int CountNext(string id);
}
