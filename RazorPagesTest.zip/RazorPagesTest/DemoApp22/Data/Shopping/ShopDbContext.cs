//using: Imports the Microsoft.EntityFrameworkCore namespace, which provides APIs for interacting with relational databases using Entity Framework Core (EF Core).
using Microsoft.EntityFrameworkCore;

namespace DemoApp.Data.Shopping;

//public class ShopDbContext: This is the database context class that acts as the bridge between the database and your C# code.
//DbContextOptions options: This constructor receives database configuration options (like which provider to use and the connection string).
                          //These options are passed to the base class constructor (DbContext) to set up the context.
//: DbContext(options): This is constructor chaining, where the base class DbContext is initialized with the provided options.
public class ShopDbContext(DbContextOptions options) : DbContext(options)
{
    //Represents a table in the database, where each row is mapped to a Customer object.
    public DbSet<Customer> Customers { get; set; }
}
