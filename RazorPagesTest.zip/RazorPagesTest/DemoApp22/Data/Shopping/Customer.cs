//System.ComponentModel.DataAnnotations: Provides attributes for validating data models (e.g., Required).
//System.ComponentModel.DataAnnotations.Schema: Contains attributes for configuring how the class and its properties map to a database (e.g., Table, Column).
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoApp.Data.Shopping;

//public class Customer: This class represents the Customer entity in the application.
//[Table("CustomerInfo")]: This attribute specifies that this class maps to the CustomerInfo table in the database.
//Without this attribute, EF Core would assume the table name is Customers (based on the class name).
[Table("CustomerInfo")]
public class Customer
{
    //[Column("UserName")]: Maps the Id property to the UserName column in the database.
    //[Required]: Ensures that this property must have a value (cannot be null).
    //string Id { get; set; } = string.Empty;: Represents the unique identifier for the customer (e.g., username). It is initialized to an empty string to avoid null values.
    [Column("UserName"), Required]
    public string Id { get; set; } = string.Empty;

    //[Required]: Marks this property as mandatory.
    //string Password { get; set; } = string.Empty;: Stores the customer’s password, initialized to an empty string to avoid null values.
    [Required(ErrorMessage = "Please provide password")]
    public string Password { get; set; } = string.Empty;

    public List<Order> Orders { get; set; }
}


// How This Works in EF Core
// Entity Framework Core (EF Core) will map this class to the CustomerInfo table and its properties to the corresponding columns (UserName and Password).
// The [Required] attributes enforce validation on both properties at runtime or during database operations.
// When interacting with the database using EF Core, this class allows you to perform CRUD operations on the CustomerInfo table.