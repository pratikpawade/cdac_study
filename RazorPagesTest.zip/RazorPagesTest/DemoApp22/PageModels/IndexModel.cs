using System.Security.Claims;
using DemoApp.Data.Shopping;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DemoApp.PageModels;

//IndexModel: A class representing the model for the Index Razor Page.
//(ShopDbContext shop): Constructor injection: The shop instance of the ShopDbContext database context is provided by the Dependency Injection (DI) container when this page model is created.
//PageModel: A base class for Razor Page models, providing HTTP request handling methods.
public class IndexModel(ShopDbContext shop) : PageModel
{
    //[BindProperty]: Binds form data from the Razor Page to this property when the form is submitted.
    //Customer Input { get; set; }: A property of type Customer that holds input data from the user (such as Customer ID and Password).
    //= new();: Initializes the Input property with a new Customer object.
    [BindProperty]
    public Customer Input { get; set; } = new();

    //async Task<IActionResult>: Indicates that the method is asynchronous and returns a task that resolves to an IActionResult (used to represent HTTP responses).
    //OnPostAsync: Razor Pages convention to handle HTTP POST requests.
    public async Task<IActionResult> OnPostAsync()
    {
        //ModelState: Tracks the state of model validation and form data binding.
        //IsValid: Returns true if all validation rules are satisfied.
        if(ModelState.IsValid)
        {
            //shop.Customers: Refers to the Customers table from the ShopDbContext.
            //FindAsync(Input.Id): Asynchronously searches for a customer with the specified ID.
            var customer = await shop.Customers.FindAsync(Input.Id);
            
            //customer?.Password == Input.Password: If the customer exists and the password matches, authentication continues.
            if(customer?.Password == Input.Password)
            {
                //Represents the user identity. The "Customer" argument names the authentication type.
                var identity = new ClaimsIdentity("Customer");
                
                //Adds a claim (a piece of user information). Here, the customer ID is added as the user's name.
                identity.AddClaim(new Claim(ClaimTypes.Name, Input.Id));
                
                //Signs in the user by attaching the identity to the HTTP context using cookies or other authentication mechanisms.
                await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
                return RedirectToPage("Detail");
            }
            else
            {
                //ModelState.AddModelError(): Adds an error to the ModelState, which can be displayed to the user if authentication fails.
                ModelState.AddModelError("Login", "Invalid Customer ID or Password");
            }
        }
        return Page();
    }
}