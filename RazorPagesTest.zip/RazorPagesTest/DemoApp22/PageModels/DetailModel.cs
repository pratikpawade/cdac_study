// DemoApp.Data.Shopping: Provides access to the data models and database context, such as ShopDbContext and Customer.
// Microsoft.AspNetCore.Authentication: Used for handling authentication-related operations (e.g., logging out).
// Microsoft.AspNetCore.Mvc and Microsoft.AspNetCore.Mvc.RazorPages: Contain Razor Pages infrastructure and result types (like IActionResult).
using DemoApp.Data.Shopping;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DemoApp.PageModels;


// [ResponseCache(NoStore = true)]:
// This ensures that the page is not cached by the browser or any intermediate proxy.
// Important for security—especially for pages that contain sensitive data, like customer orders.
// DetailModel(ShopDbContext shop) : PageModel:
// Inherits from PageModel, meaning this class represents the logic behind a Razor Page.
// The ShopDbContext is injected via dependency injection to interact with the database.
[ResponseCache(NoStore = true)]
public class DetailModel(ShopDbContext shop) : PageModel
{
    public Customer Output { get; set; }

//OnGetAsync:
//This method is executed when the page is accessed via an HTTP GET request.
//Database Lookup:
//User.Identity.Name: Retrieves the name of the logged-in user (set during login).
//FindAsync: Fetches the corresponding customer record from the Customers table.
//LoadAsync: Loads the related orders for the customer using EF Core's lazy loading pattern.
//This ensures that the Orders collection (if it exists) is loaded alongside the customer data.
    public async Task OnGetAsync()
    {
        Output = await shop.Customers.FindAsync(User.Identity.Name);
        await shop.Entry(Output).Collection(p => p.Orders).LoadAsync();
    }

//OnGetLogoutAsync:
//This method handles logout logic when the user accesses the /Detail?handler=Logout route.
//SignOutAsync(): Clears the authentication cookie, effectively logging the user out.
//RedirectToPage("Index"): After logging out, the user is redirected to the Index page.
    public async Task<IActionResult> OnGetLogoutAsync()
    {
        await HttpContext.SignOutAsync();
        return RedirectToPage("Index");
    }
}
