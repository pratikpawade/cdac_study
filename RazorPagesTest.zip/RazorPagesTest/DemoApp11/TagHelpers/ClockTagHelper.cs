using Microsoft.AspNetCore.Razor.TagHelpers;

namespace DemoApp.TagHelpers;

[HtmlTargetElement("span", Attributes = "time-display-format")]
//Defines a class named ClockTagHelper, which inherits from the TagHelper base class.
//Inheriting from TagHelper gives this class the ability to modify or enhance HTML tags.
public class ClockTagHelper : TagHelper
{
    //Defines a property named TimeDisplayFormat.
    //When the time-display-format attribute is used in HTML, its value will be assigned to this property.
    public string TimeDisplayFormat { get; set; }

    //This Process method gets called whenever the <span> element with the time-display-format attribute is rendered.
    //TagHelperContext context: Provides information about the HTML element and its attributes.
    //TagHelperOutput output: Represents the output of the tag and allows us to modify its content.
    public override void Process(TagHelperContext context, TagHelperOutput output)
    {
        //Gets the current date and time using DateTime.Now and formats it according to the value of TimeDisplayFormat.
        var time = DateTime.Now.ToString(TimeDisplayFormat);
        output.Content.SetContent(time);
    }
}