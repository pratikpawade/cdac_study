using DemoApp.Services;

//Initializes core services like logging, configuration, and dependency injection.
//Prepares the app's structure before building it.
var builder = WebApplication.CreateBuilder(args);

//Razor Pages is an ASP.NET Core framework for building dynamic pages with HTML, C#, and Razor syntax.
//This call makes Razor Pages available so that they can be mapped to routes later.
//builder.Services: Refers to the service collection where you register services that your application will use (dependency injection).
//AddRazorPages(): Adds support for Razor Pages to the project. Razor Pages are an alternative to MVC (Model-View-Controller), used for building web UIs.
builder.Services.AddRazorPages(); //enable razor-pages

//Purpose: Registers ICounter with CommonCounter as a singleton service in the dependency injection (DI) container.
//How it works: ICounter is likely an interface, and CommonCounter is its implementation.
//Singleton means only one instance of CommonCounter will be created and shared throughout the app's lifetime.
//Usage Example: If any Razor Page or Controller asks for an ICounter in its constructor, the same instance of CommonCounter will be provided each time.
builder.Services.AddSingleton<ICounter, CommonCounter>();

//Converts the configured builder into a WebApplication object.
//This app object represents the actual web application that will be hosted and run.
var app = builder.Build();


//map handler for ~/Pages/X.cshtml to the path indicated
//by @page directive in X.cshtml, if this path is not
//specified map it to /X with X=Index by default
app.MapRazorPages();
app.Run();
